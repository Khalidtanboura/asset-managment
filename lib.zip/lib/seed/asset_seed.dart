import '../repositories/asset_repository.dart';
import '../src/data/mock_asset_repository.dart';

class AssetSeeder {
  AssetSeeder._();

  static Future<void> seedDatabase() async {
    final repository = AssetRepository();

    // هل توجد بيانات مسبقاً؟
    final assets = await repository.getAllAssets();

    if (assets.isNotEmpty) {
      return;
    }

    // إدخال البيانات الوهمية مرة واحدة فقط
    for (final asset in MockAssetRepository.seedAssets) {
      await repository.insertAsset(asset);
    }
  }
}
