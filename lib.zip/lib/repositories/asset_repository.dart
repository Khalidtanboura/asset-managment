import 'package:sqflite/sqflite.dart';

import '../database/asset_database.dart';
import '../src/models/asset.dart';

class AssetRepository {
  AssetRepository();

  Future<Database> get _db async => AssetDatabase.instance.database;

  // =========================
  // Get All Assets
  // =========================
  Future<List<Asset>> getAllAssets() async {
    final db = await _db;

    final result = await db.query('assets', orderBy: 'name');

    return result.map(_fromMap).toList();
  }

  // =========================
  // Get Asset By Id
  // =========================
  Future<Asset?> getAssetById(String id) async {
    final db = await _db;

    final result = await db.query('assets', where: 'id = ?', whereArgs: [id]);

    if (result.isEmpty) return null;

    return _fromMap(result.first);
  }

  // =========================
  // Insert Asset
  // =========================
  Future<void> insertAsset(Asset asset) async {
    final db = await _db;

    await db.insert(
      'assets',
      _toMap(asset),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // =========================
  // Update Asset
  // =========================
  Future<void> updateAsset(Asset asset) async {
    final db = await _db;

    await db.update(
      'assets',
      _toMap(asset),
      where: 'id = ?',
      whereArgs: [asset.id],
    );
  }

  // =========================
  // Delete Asset
  // =========================
  Future<void> deleteAsset(String id) async {
    final db = await _db;

    await db.delete('assets', where: 'id = ?', whereArgs: [id]);
  }

  // =========================
  // Asset -> Map
  // =========================
  Map<String, dynamic> _toMap(Asset asset) {
    return {
      'id': asset.id,
      'name': asset.name,
      'category': asset.category,
      'location': asset.location,
      'status': asset.status.index,
      'lastMaintenance': asset.lastMaintenance.toIso8601String(),
      'nextMaintenance': asset.nextMaintenance.toIso8601String(),
      'health': asset.health,
      'manual': asset.manual,
      'maintenanceIntervalMonths': asset.maintenanceIntervalMonths,
    };
  }

  // =========================
  // Map -> Asset
  // =========================
  Asset _fromMap(Map<String, dynamic> map) {
    return Asset(
      id: map['id'],
      name: map['name'],
      category: map['category'],
      location: map['location'],
      status: AssetStatus.values[map['status']],
      lastMaintenance: DateTime.parse(map['lastMaintenance']),
      nextMaintenance: DateTime.parse(map['nextMaintenance']),
      health: map['health'],
      manual: map['manual'],
      maintenanceIntervalMonths: map['maintenanceIntervalMonths'],
    );
  }
}
