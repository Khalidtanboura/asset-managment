import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class AssetDatabase {
  AssetDatabase._();

  static final AssetDatabase instance = AssetDatabase._();

  Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;

    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final dbPath = await getDatabasesPath();

    final path = join(dbPath, 'asset_management.db');

    return await openDatabase(path, version: 1, onCreate: _createDatabase);
  }

  Future<void> _createDatabase(Database db, int version) async {
    await db.execute('''
      CREATE TABLE assets(
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        category TEXT NOT NULL,
        location TEXT NOT NULL,
        status INTEGER NOT NULL,
        lastMaintenance TEXT NOT NULL,
        nextMaintenance TEXT NOT NULL,
        health INTEGER NOT NULL,
        manual TEXT NOT NULL,
        maintenanceIntervalMonths INTEGER NOT NULL
      )
    ''');
  }
}
