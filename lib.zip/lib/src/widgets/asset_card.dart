import 'package:flutter/material.dart';

import '../models/asset.dart';
import '../utils/date_formatter.dart';

class AssetCard extends StatelessWidget {
  const AssetCard({super.key, required this.asset, required this.onTap});

  final Asset asset;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        child: ListTile(
          onTap: onTap,
          leading: CircleAvatar(
            backgroundColor: const Color(0xFFE3F3EF),
            child: Text(
              '${asset.health}',
              style: const TextStyle(
                color: Color(0xFF1B6B5F),
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          title: Text(
            asset.name,
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          subtitle: Text(
            '${asset.location}\n${asset.status.label} - القادم: ${DateFormatter.short(asset.nextMaintenance)}',
          ),
          isThreeLine: true,
          trailing: const Icon(Icons.chevron_left),
        ),
      ),
    );
  }
}
