import 'package:flutter/material.dart';

class ScanPanel extends StatelessWidget {
  const ScanPanel({
    super.key,
    required this.online,
    required this.lastMessage,
    required this.onQrScan,
    required this.onNfcScan,
  });

  final bool online;
  final String lastMessage;
  final VoidCallback onQrScan;
  final VoidCallback onNfcScan;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: const Color(0xFF173832),
        borderRadius: BorderRadius.circular(22),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            online ? Icons.wifi : Icons.wifi_off,
            color: const Color(0xFFB7E4D8),
          ),
          const SizedBox(height: 12),
          const Text(
            'ابدأ من تعريف الأصل',
            style: TextStyle(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'امسح QR أو NFC لجلب بيانات الجهاز من الخادم ثم نفذ المهمة ميدانيًا.',
            style: TextStyle(color: Color(0xFFD9ECE7)),
          ),
          if (lastMessage.isNotEmpty) ...[
            const SizedBox(height: 10),
            Text(lastMessage, style: const TextStyle(color: Color(0xFFB7E4D8))),
          ],
          const SizedBox(height: 18),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              FilledButton.icon(
                onPressed: onQrScan,
                icon: const Icon(Icons.qr_code_scanner),
                label: const Text('مسح QR'),
              ),
              OutlinedButton.icon(
                onPressed: onNfcScan,
                icon: const Icon(Icons.nfc),
                label: const Text('قراءة NFC'),
                style: OutlinedButton.styleFrom(foregroundColor: Colors.white),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
