import 'package:flutter/material.dart';

import '../seed/asset_seed.dart';
import 'controllers/asset_controller.dart';
import 'data/local_task_store.dart';
import 'data/mock_asset_repository.dart';
import 'screens/home_shell.dart';
import 'services/asset_scanner_service.dart';
import 'services/geofence_service.dart';
import 'services/notification_service.dart';
import 'services/sync_service.dart';
import 'theme/app_theme.dart';

class AssetManagementApp extends StatefulWidget {
  const AssetManagementApp({super.key});

  @override
  State<AssetManagementApp> createState() => _AssetManagementAppState();
}

class _AssetManagementAppState extends State<AssetManagementApp> {
  late final AssetController controller;

  @override
  void initState() {
    super.initState();

    controller = AssetController(
      assetRepository: MockAssetRepository(),
      localTaskStore: LocalTaskStore(),
      scannerService: AssetScannerService(),
      geofenceService: GeofenceService(),
      syncService: SyncService(),
      notificationService: NotificationService(),
    );

    _initialize();
  }

  Future<void> _initialize() async {
    await AssetSeeder.seedDatabase();

    controller.loadInitialData();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'إدارة الأصول',
      theme: AppTheme.light,
      home: Directionality(
        textDirection: TextDirection.rtl,
        child: HomeShell(controller: controller),
      ),
    );
  }
}
