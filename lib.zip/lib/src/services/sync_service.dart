import '../models/maintenance_task.dart';

class SyncService {
  List<MaintenanceTask> syncPendingTasks(List<MaintenanceTask> tasks) {
    return [
      for (final task in tasks)
        if (task.syncState == TaskSyncState.pending)
          task.copyWith(syncState: TaskSyncState.synced)
        else
          task,
    ];
  }
}
