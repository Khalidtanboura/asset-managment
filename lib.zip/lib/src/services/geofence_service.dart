import '../models/asset.dart';

class GeofenceService {
  bool verifyTechnicianNearAsset(Asset asset) {
    return asset.id != 'AC-207';
  }
}
