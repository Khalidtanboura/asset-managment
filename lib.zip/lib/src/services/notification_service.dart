class NotificationService {
  final List<String> _messages = [];

  List<String> get messages => List.unmodifiable(_messages);

  void notifyTaskCompleted(String assetName) {
    _messages.insert(0, 'تم إتمام مهمة الصيانة على $assetName وإبلاغ المدير.');
  }

  void notifySyncCompleted(int count) {
    _messages.insert(0, 'تمت مزامنة $count مهمة محفوظة محليًا.');
  }
}
