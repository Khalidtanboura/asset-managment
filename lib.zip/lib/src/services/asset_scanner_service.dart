class ScanResult {
  const ScanResult({required this.assetId, required this.source});

  final String assetId;
  final String source;
}

class AssetScannerService {
  ScanResult scanQrCode() {
    return const ScanResult(assetId: 'GEN-001', source: 'QR');
  }

  ScanResult scanNfcTag() {
    return const ScanResult(assetId: 'PMP-014', source: 'NFC');
  }
}
