import 'package:flutter/material.dart';

import '../controllers/asset_controller.dart';
import '../models/maintenance_task.dart';
import '../utils/date_formatter.dart';
import '../widgets/check_action_tile.dart';
import '../widgets/info_line.dart';
import '../widgets/surface_card.dart';

class TaskScreen extends StatelessWidget {
  const TaskScreen({super.key, required this.controller});

  final AssetController controller;

  @override
  Widget build(BuildContext context) {
    final asset = controller.selectedAsset;
    if (asset == null) {
      return const Center(
        child: Text('اختر أصلًا أو امسح QR/NFC لبدء المهمة.'),
      );
    }

    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        SurfaceCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                asset.name,
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Text(asset.id, style: const TextStyle(color: Color(0xFF60746F))),
              const Divider(height: 26),
              InfoLine(icon: Icons.category_outlined, text: asset.category),
              InfoLine(icon: Icons.place_outlined, text: asset.location),
              InfoLine(
                icon: Icons.health_and_safety_outlined,
                text: 'الحالة: ${asset.status.label}',
              ),
              InfoLine(
                icon: Icons.event_available,
                text:
                    'الصيانة القادمة: ${DateFormatter.short(asset.nextMaintenance)}',
              ),
              InfoLine(icon: Icons.menu_book_outlined, text: asset.manual),
            ],
          ),
        ),
        const SizedBox(height: 14),
        SegmentedButton<MaintenanceType>(
          segments: [
            for (final type in MaintenanceType.values)
              ButtonSegment(
                value: type,
                label: Text(type.label),
                icon: Icon(_iconForType(type)),
              ),
          ],
          selected: {controller.draft.type},
          onSelectionChanged: (value) => controller.updateTaskType(value.first),
        ),
        const SizedBox(height: 14),
        CheckActionTile(
          icon: Icons.gps_fixed,
          title: 'إثبات الموقع',
          subtitle: controller.draft.gpsVerified
              ? 'الفني داخل نطاق الأصل'
              : 'اضغط للتحقق عبر GPS',
          active: controller.draft.gpsVerified,
          onTap: controller.verifyLocation,
        ),
        CheckActionTile(
          icon: Icons.photo_camera_outlined,
          title: 'صورة قبل العمل',
          subtitle: controller.draft.beforePhotoPath.isNotEmpty
              ? 'تم حفظ الصورة محليًا'
              : 'اضغط لمحاكاة التقاط صورة',
          active: controller.draft.beforePhotoPath.isNotEmpty,
          onTap: controller.captureBeforePhoto,
        ),
        const SizedBox(height: 10),
        TextField(
          maxLines: 3,
          decoration: const InputDecoration(labelText: 'الملاحظات الميدانية'),
          onChanged: controller.updateNotes,
        ),
        const SizedBox(height: 10),
        TextField(
          decoration: const InputDecoration(labelText: 'قطع الغيار المستبدلة'),
          onChanged: controller.updateReplacedParts,
        ),
        const SizedBox(height: 10),
        TextField(
          decoration: const InputDecoration(labelText: 'التوقيع الرقمي'),
          onChanged: controller.updateSignature,
        ),
        const SizedBox(height: 18),
        FilledButton.icon(
          onPressed: () {
            final error = controller.closeTask();
            if (error != null) {
              ScaffoldMessenger.of(
                context,
              ).showSnackBar(SnackBar(content: Text(error)));
            }
          },
          icon: const Icon(Icons.verified_outlined),
          label: const Text('إغلاق المهمة وتحديث الأصل'),
        ),
      ],
    );
  }

  IconData _iconForType(MaintenanceType type) {
    return switch (type) {
      MaintenanceType.scheduled => Icons.event_repeat,
      MaintenanceType.repair => Icons.build_outlined,
      MaintenanceType.inspection => Icons.fact_check_outlined,
    };
  }
}
