import 'package:flutter/material.dart';

import '../controllers/asset_controller.dart';
import '../widgets/asset_card.dart';
import '../widgets/metric_card.dart';
import '../widgets/scan_panel.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key, required this.controller});

  final AssetController controller;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        ScanPanel(
          online: controller.online,
          lastMessage: controller.lastScanMessage,
          onQrScan: controller.scanQrCode,
          onNfcScan: controller.scanNfcTag,
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: MetricCard(
                title: 'الأصول',
                value: '${controller.assets.length}',
                icon: Icons.inventory_2_outlined,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: MetricCard(
                title: 'مهام محفوظة',
                value: '${controller.tasks.length}',
                icon: Icons.task_alt,
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        Text(
          'الأصول المسجلة',
          style: Theme.of(
            context,
          ).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10),
        for (final asset in controller.assets)
          AssetCard(asset: asset, onTap: () => controller.selectAsset(asset)),
      ],
    );
  }
}
