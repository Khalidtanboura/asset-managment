import 'package:flutter/material.dart';

import '../controllers/asset_controller.dart';
import 'dashboard_screen.dart';
import 'reports_screen.dart';
import 'task_screen.dart';

class HomeShell extends StatelessWidget {
  const HomeShell({super.key, required this.controller});

  final AssetController controller;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: controller,
      builder: (context, _) {
        return Scaffold(
          appBar: AppBar(
            title: const Text('إدارة الأصول'),
            actions: [
              IconButton(
                tooltip: controller.online ? 'متصل' : 'غير متصل',
                onPressed: controller.toggleConnection,
                icon: Icon(
                  controller.online ? Icons.cloud_done : Icons.cloud_off,
                ),
              ),
            ],
          ),
          body: SafeArea(
            child: IndexedStack(
              index: controller.selectedTab,
              children: [
                DashboardScreen(controller: controller),
                TaskScreen(controller: controller),
                ReportsScreen(controller: controller),
              ],
            ),
          ),
          bottomNavigationBar: NavigationBar(
            selectedIndex: controller.selectedTab,
            onDestinationSelected: controller.changeTab,
            destinations: const [
              NavigationDestination(
                icon: Icon(Icons.dashboard_outlined),
                selectedIcon: Icon(Icons.dashboard),
                label: 'الرئيسية',
              ),
              NavigationDestination(
                icon: Icon(Icons.assignment_outlined),
                selectedIcon: Icon(Icons.assignment_turned_in),
                label: 'المهمة',
              ),
              NavigationDestination(
                icon: Icon(Icons.analytics_outlined),
                selectedIcon: Icon(Icons.analytics),
                label: 'التقارير',
              ),
            ],
          ),
        );
      },
    );
  }
}
