import 'package:flutter/material.dart';

import '../controllers/asset_controller.dart';
import '../models/maintenance_task.dart';
import '../utils/date_formatter.dart';
import '../widgets/surface_card.dart';

class ReportsScreen extends StatelessWidget {
  const ReportsScreen({super.key, required this.controller});

  final AssetController controller;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        SurfaceCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'التقارير والتحليل',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              Text('متوسط صحة الأصول: ${controller.averageHealth}%'),
              Text('المهام غير المتزامنة: ${controller.pendingSyncCount}'),
              Text('الإشعارات: ${controller.notifications.length}'),
              const SizedBox(height: 14),
              FilledButton.icon(
                onPressed: controller.syncPendingTasks,
                icon: const Icon(Icons.sync),
                label: const Text('مزامنة المهام المحلية'),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        Text(
          'سجل الصيانة',
          style: Theme.of(
            context,
          ).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10),
        for (final task in controller.tasks) _TaskHistoryCard(task: task),
        if (controller.tasks.isEmpty)
          const Padding(
            padding: EdgeInsets.only(top: 40),
            child: Center(
              child: Text('لا توجد مهام بعد. ابدأ من مسح أصل وتنفيذ مهمة.'),
            ),
          ),
        const SizedBox(height: 16),
        if (controller.notifications.isNotEmpty)
          Text(
            'آخر الإشعارات',
            style: Theme.of(
              context,
            ).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
          ),
        for (final message in controller.notifications)
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: SurfaceCard(
              child: Row(
                children: [
                  const Icon(
                    Icons.notifications_active_outlined,
                    color: Color(0xFF1B6B5F),
                  ),
                  const SizedBox(width: 10),
                  Expanded(child: Text(message)),
                ],
              ),
            ),
          ),
      ],
    );
  }
}

class _TaskHistoryCard extends StatelessWidget {
  const _TaskHistoryCard({required this.task});

  final MaintenanceTask task;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: SurfaceCard(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(
              task.syncState == TaskSyncState.synced
                  ? Icons.cloud_done
                  : Icons.storage,
              color: const Color(0xFF1B6B5F),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${task.type.label} - ${task.assetId}',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 4),
                  Text('التاريخ: ${DateFormatter.short(task.createdAt)}'),
                  Text('الحالة: ${task.syncState.label}'),
                  Text('الملاحظات: ${task.notes}'),
                  Text('قطع الغيار: ${task.replacedParts}'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
