import '../models/asset.dart';

class MockAssetRepository {
  static final List<Asset> seedAssets = [
    Asset(
      id: 'GEN-001',
      name: 'مولد كهربائي رئيسي',
      category: 'طاقة',
      location: 'مبنى A - غرفة الطاقة',
      status: AssetStatus.operational,
      lastMaintenance: DateTime(2026, 1, 7),
      nextMaintenance: DateTime(2026, 7, 7),
      health: 92,
      maintenanceIntervalMonths: 6,
      manual: 'فحص الزيت، الفلاتر، الوقود، الاهتزاز، وقراءة لوحة الإنذار.',
    ),
    Asset(
      id: 'PMP-014',
      name: 'مضخة مياه احتياطية',
      category: 'مرافق',
      location: 'القبو - محطة الضخ',
      status: AssetStatus.needsAttention,
      lastMaintenance: DateTime(2026, 3, 12),
      nextMaintenance: DateTime(2026, 9, 12),
      health: 76,
      maintenanceIntervalMonths: 6,
      manual: 'اختبار الضغط، تنظيف الصمام، وفحص التسريب حول جسم المضخة.',
    ),
    Asset(
      id: 'AC-207',
      name: 'وحدة تكييف مركزية',
      category: 'تكييف',
      location: 'السطح - القطاع الشرقي',
      status: AssetStatus.underMaintenance,
      lastMaintenance: DateTime(2026, 6, 1),
      nextMaintenance: DateTime(2026, 12, 1),
      health: 61,
      maintenanceIntervalMonths: 6,
      manual: 'تنظيف الفلاتر، قياس ضغط الغاز، ومراجعة صوت الضاغط.',
    ),
  ];

  List<Asset> getAllAssets() => List.unmodifiable(seedAssets);

  Asset? getAssetById(String id) {
    for (final asset in seedAssets) {
      if (asset.id == id) return asset;
    }
    return null;
  }

  void updateAssetAfterMaintenance(String assetId, DateTime completedAt) {
    final index = seedAssets.indexWhere((asset) => asset.id == assetId);
    if (index == -1) return;

    final asset = seedAssets[index];
    seedAssets[index] = asset.copyWith(
      status: AssetStatus.operational,
      health: 96,
      lastMaintenance: completedAt,
      nextMaintenance: DateTime(
        completedAt.year,
        completedAt.month + asset.maintenanceIntervalMonths,
        completedAt.day,
      ),
    );
  }
}
