import '../models/maintenance_task.dart';

class LocalTaskStore {
  final List<MaintenanceTask> _tasks = [];

  List<MaintenanceTask> getAllTasks() => List.unmodifiable(_tasks);

  void saveTask(MaintenanceTask task) {
    _tasks.insert(0, task);
  }

  void replaceAll(List<MaintenanceTask> tasks) {
    _tasks
      ..clear()
      ..addAll(tasks);
  }
}
