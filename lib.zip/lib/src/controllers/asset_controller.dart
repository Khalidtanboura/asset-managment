import 'package:flutter/foundation.dart';

import '../data/local_task_store.dart';
import '../data/mock_asset_repository.dart';
import '../models/asset.dart';
import '../models/maintenance_draft.dart';
import '../models/maintenance_task.dart';
import '../services/asset_scanner_service.dart';
import '../services/geofence_service.dart';
import '../services/notification_service.dart';
import '../services/sync_service.dart';

class AssetController extends ChangeNotifier {
  AssetController({
    required this.assetRepository,
    required this.localTaskStore,
    required this.scannerService,
    required this.geofenceService,
    required this.syncService,
    required this.notificationService,
  });

  final MockAssetRepository assetRepository;
  final LocalTaskStore localTaskStore;
  final AssetScannerService scannerService;
  final GeofenceService geofenceService;
  final SyncService syncService;
  final NotificationService notificationService;

  List<Asset> assets = [];
  List<MaintenanceTask> tasks = [];
  Asset? selectedAsset;
  MaintenanceDraft draft = const MaintenanceDraft();
  bool online = true;
  int selectedTab = 0;
  String lastScanMessage = '';

  int get pendingSyncCount {
    return tasks
        .where((task) => task.syncState == TaskSyncState.pending)
        .length;
  }

  int get averageHealth {
    if (assets.isEmpty) return 0;
    final total = assets.fold<int>(0, (sum, asset) => sum + asset.health);
    return (total / assets.length).round();
  }

  List<String> get notifications => notificationService.messages;

  void loadInitialData() {
    assets = assetRepository.getAllAssets();
    tasks = localTaskStore.getAllTasks();
    selectedAsset = assets.isNotEmpty ? assets.first : null;
    notifyListeners();
  }

  void changeTab(int index) {
    selectedTab = index;
    notifyListeners();
  }

  void toggleConnection() {
    online = !online;
    notifyListeners();
  }

  void selectAsset(Asset asset) {
    selectedAsset = asset;
    selectedTab = 1;
    draft = const MaintenanceDraft();
    notifyListeners();
  }

  void scanQrCode() {
    _handleScan(scannerService.scanQrCode());
  }

  void scanNfcTag() {
    _handleScan(scannerService.scanNfcTag());
  }

  void _handleScan(ScanResult result) {
    final asset = assetRepository.getAssetById(result.assetId);
    if (asset == null) {
      lastScanMessage = 'لم يتم العثور على أصل برقم ${result.assetId}.';
      notifyListeners();
      return;
    }

    lastScanMessage = 'تمت قراءة ${result.source} للأصل ${asset.name}.';
    selectAsset(asset);
  }

  void updateTaskType(MaintenanceType type) {
    draft = draft.copyWith(type: type);
    notifyListeners();
  }

  void updateNotes(String value) {
    draft = draft.copyWith(notes: value);
    notifyListeners();
  }

  void updateReplacedParts(String value) {
    draft = draft.copyWith(replacedParts: value);
    notifyListeners();
  }

  void captureBeforePhoto() {
    final assetId = selectedAsset?.id ?? 'unknown';
    draft = draft.copyWith(beforePhotoPath: 'local/photos/$assetId-before.jpg');
    notifyListeners();
  }

  void verifyLocation() {
    final asset = selectedAsset;
    if (asset == null) return;
    draft = draft.copyWith(
      gpsVerified: geofenceService.verifyTechnicianNearAsset(asset),
    );
    notifyListeners();
  }

  void updateSignature(String value) {
    draft = draft.copyWith(signature: value);
    notifyListeners();
  }

  String? closeTask() {
    final asset = selectedAsset;
    if (asset == null) return 'اختر أصلًا قبل تنفيذ المهمة.';
    if (!draft.isReadyToClose) {
      return 'المهمة تحتاج إثبات موقع وصورة قبل العمل وتوقيع رقمي.';
    }

    final completedAt = DateTime.now();
    final task = MaintenanceTask(
      id: 'TASK-${completedAt.millisecondsSinceEpoch}',
      assetId: asset.id,
      type: draft.type,
      notes: draft.notes.trim().isEmpty
          ? 'لا توجد ملاحظات إضافية.'
          : draft.notes.trim(),
      replacedParts: draft.replacedParts.trim().isEmpty
          ? 'لم يتم استبدال قطع.'
          : draft.replacedParts.trim(),
      beforePhotoPath: draft.beforePhotoPath,
      gpsVerified: draft.gpsVerified,
      signature: draft.signature.trim(),
      createdAt: completedAt,
      syncState: online ? TaskSyncState.synced : TaskSyncState.pending,
    );

    localTaskStore.saveTask(task);
    assetRepository.updateAssetAfterMaintenance(asset.id, completedAt);
    assets = assetRepository.getAllAssets();
    tasks = localTaskStore.getAllTasks();
    selectedAsset = assetRepository.getAssetById(asset.id);
    draft = const MaintenanceDraft();
    selectedTab = 2;
    notificationService.notifyTaskCompleted(asset.name);
    notifyListeners();
    return null;
  }

  void syncPendingTasks() {
    final pendingBefore = pendingSyncCount;
    online = true;
    tasks = syncService.syncPendingTasks(tasks);
    localTaskStore.replaceAll(tasks);
    notificationService.notifySyncCompleted(pendingBefore);
    notifyListeners();
  }
}
