enum AssetStatus {
  operational('يعمل بكفاءة'),
  needsAttention('بحاجة متابعة'),
  underMaintenance('تحت الصيانة');

  const AssetStatus(this.label);

  final String label;
}

class Asset {
  const Asset({
    required this.id,
    required this.name,
    required this.category,
    required this.location,
    required this.status,
    required this.lastMaintenance,
    required this.nextMaintenance,
    required this.health,
    required this.manual,
    required this.maintenanceIntervalMonths,
  });

  final String id;
  final String name;
  final String category;
  final String location;
  final AssetStatus status;
  final DateTime lastMaintenance;
  final DateTime nextMaintenance;
  final int health;
  final String manual;
  final int maintenanceIntervalMonths;

  Asset copyWith({
    String? id,
    String? name,
    String? category,
    String? location,
    AssetStatus? status,
    DateTime? lastMaintenance,
    DateTime? nextMaintenance,
    int? health,
    String? manual,
    int? maintenanceIntervalMonths,
  }) {
    return Asset(
      id: id ?? this.id,
      name: name ?? this.name,
      category: category ?? this.category,
      location: location ?? this.location,
      status: status ?? this.status,
      lastMaintenance: lastMaintenance ?? this.lastMaintenance,
      nextMaintenance: nextMaintenance ?? this.nextMaintenance,
      health: health ?? this.health,
      manual: manual ?? this.manual,
      maintenanceIntervalMonths:
          maintenanceIntervalMonths ?? this.maintenanceIntervalMonths,
    );
  }
}
