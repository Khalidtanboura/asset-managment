enum MaintenanceType {
  scheduled('صيانة دورية'),
  repair('إصلاح عطل مفاجئ'),
  inspection('فحص سلامة');

  const MaintenanceType(this.label);

  final String label;
}

enum TaskSyncState {
  synced('متزامنة'),
  pending('محفوظة محليًا'),
  failed('فشلت المزامنة');

  const TaskSyncState(this.label);

  final String label;
}

class MaintenanceTask {
  const MaintenanceTask({
    required this.id,
    required this.assetId,
    required this.type,
    required this.notes,
    required this.replacedParts,
    required this.beforePhotoPath,
    required this.gpsVerified,
    required this.signature,
    required this.createdAt,
    required this.syncState,
  });

  final String id;
  final String assetId;
  final MaintenanceType type;
  final String notes;
  final String replacedParts;
  final String beforePhotoPath;
  final bool gpsVerified;
  final String signature;
  final DateTime createdAt;
  final TaskSyncState syncState;

  MaintenanceTask copyWith({TaskSyncState? syncState}) {
    return MaintenanceTask(
      id: id,
      assetId: assetId,
      type: type,
      notes: notes,
      replacedParts: replacedParts,
      beforePhotoPath: beforePhotoPath,
      gpsVerified: gpsVerified,
      signature: signature,
      createdAt: createdAt,
      syncState: syncState ?? this.syncState,
    );
  }
}
