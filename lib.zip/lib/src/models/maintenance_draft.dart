import 'maintenance_task.dart';

class MaintenanceDraft {
  const MaintenanceDraft({
    this.type = MaintenanceType.scheduled,
    this.notes = '',
    this.replacedParts = '',
    this.beforePhotoPath = '',
    this.gpsVerified = false,
    this.signature = '',
  });

  final MaintenanceType type;
  final String notes;
  final String replacedParts;
  final String beforePhotoPath;
  final bool gpsVerified;
  final String signature;

  bool get isReadyToClose {
    return gpsVerified &&
        beforePhotoPath.isNotEmpty &&
        signature.trim().isNotEmpty;
  }

  MaintenanceDraft copyWith({
    MaintenanceType? type,
    String? notes,
    String? replacedParts,
    String? beforePhotoPath,
    bool? gpsVerified,
    String? signature,
  }) {
    return MaintenanceDraft(
      type: type ?? this.type,
      notes: notes ?? this.notes,
      replacedParts: replacedParts ?? this.replacedParts,
      beforePhotoPath: beforePhotoPath ?? this.beforePhotoPath,
      gpsVerified: gpsVerified ?? this.gpsVerified,
      signature: signature ?? this.signature,
    );
  }
}
